#!/bin/sh

../XS -v -ls $1 -n $2 -eh -eo -es -f 0.3,0.2,0.2,0.3,0.0 reference.fa
sed -i '1 i\>random sequence' reference.fa 
../mutations.pl reference.fa $3 $4 $5 mutated.fa
../art_illumina -ss MSv1 -M -p -na -i mutated.fa -l 150 -f $6 -m 200 -s 10 -o mutated

../bwa index reference.fa
../bwa aln reference.fa mutated1.fq > mutated1.sai
../bwa aln reference.fa mutated2.fq > mutated2.sai
../bwa sampe reference.fa mutated1.sai mutated2.sai mutated1.fq mutated2.fq > mutated.sam
../samtools view -b -S mutated.sam > mutated.bam 
../samtools sort mutated.bam mutated.bam.sorted
../samtools index mutated.bam.sorted.bam
../samtools mpileup -f reference.fa mutated.bam.sorted.bam > pileup
../bedtools bamtobed -i mutated.bam.sorted.bam > mutated.bed
echo mutated.bam.sorted.bam 250 mutation > configure.txt

mkdir varscan pindel scalpel
java -jar ../varscan-2.4.2-0/VarScan.jar pileup2indel pileup > varscan/indels.txt
java -jar ../varscan-2.4.2-0/VarScan.jar pileup2snp pileup > varscan/snps.txt
pindel -f reference.fa -i configure.txt -c ALL -o pindel/results
pindel2vcf -p pindel/results_SI -r reference.fa -R reference2 -d 20170520 -v pindel/SI.vcf
pindel2vcf -p pindel/results_D -r reference.fa -R reference2 -d 20170520 -v pindel/D.vcf
scalpel-discovery --single --bam mutated.bam.sorted.bam --bed mutated.bed --ref reference.fa --dir ./scalpel

