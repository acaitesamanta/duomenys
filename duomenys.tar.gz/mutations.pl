#!/usr/bin/perl -w
use strict;

my $input=$ARGV[0];
my $mutation=$ARGV[1];
my $position=$ARGV[2];
my $size=$ARGV[3];
my $output=$ARGV[4];

open INPUT, "<$input" || die "Negaliu atidaryti failo $input!\n";
open OUTPUT, ">$output" || die "Negaliu atidaryti failo $output!\n";

my $argv_size = @ARGV;
if ((($mutation eq "-i") or ($mutation eq "-d")) and ($argv_size < 5)) {
  print "Argumentų nurodyta per mažai. Rašykite ./mutations.pl file.fa -i 111 5 output.fa\n";
  exit;
} elsif ((($mutation eq "-i") or ($mutation eq "-d")) and ($argv_size > 5)) {
  print "Argumentų nurodyta per daug. Rašykite ./mutations.pl file.fa -d 111 5 output.fa\n";
  exit;
}

#nuskaitome
my $data;
while (<INPUT>) {
  if ($_ !~ /^>/) {
    $_ =~ s/\s+//g;
    $data .= $_;
  }
}

#VNP
my $fasta_len = length($data);
my $rand_position = int(rand 200) + 900;
while($fasta_len > $rand_position){

  my $nucl = substr($data, $rand_position, 1);
  my $random_nucl = '';
  if($nucl eq 'A'){
    my @chars = ("T","G","C");
    $random_nucl = $chars[int(rand @chars)];
  }
  elsif($nucl eq 'T'){
    my @chars = ("A","G","C");
    $random_nucl = $chars[int(rand @chars)];
  }
  elsif($nucl eq 'G'){
    my @chars = ("A","T","C");
    $random_nucl = $chars[int(rand @chars)];
  }
  else{
    my @chars = ("A","T","G");
    $random_nucl = $chars[int(rand @chars)];
  }

  substr($data, $rand_position, 1, $random_nucl);
  $rand_position += int(rand(200)) + 900;
}
print "Maždaug, kas 1000-ąjį nukleotidą atliktas vieno nukleotido polimorfizmas.\n";

#delecija
if ($mutation eq "-d"){
  my $deletion = substr ($data, $position, $size, '');
  print "Nuo $position pozicijos buvo ištrinti $size nukleotidai: $deletion.\n";
  print OUTPUT ">MUTATED. Nuo $position pozicijos buvo ištrinti $size nukleotidai: $deletion.\n";
}

#insercija
elsif ($mutation eq "-i"){
  my $insertion;
  my @chars = ("A","T","G", "C");
  $insertion .= $chars[int(rand @chars)] for 0..$size-1; # random insercija
  substr($data, $position, 0, $insertion);
  print "Nuo $position pozicijos buvo įterpti $size nukleotidai: $insertion.\n";
  print OUTPUT ">MUTATED. Nuo $position pozicijos buvo įterpti $size nukleotidai: $insertion.\n";
}
else{
  print "Neteisingas argumentas. Jis turi būti -i (insercijai) arba -d (delecijai).\n";
}

#spausdiname
my $i = 0;
my $len = length($data);
while($len - $i > 50){
  print OUTPUT substr($data, $i, 50), "\n";
  $i += 50;
}

print OUTPUT substr($data, $i);

close INPUT;
close OUTPUT;